import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:multi_vendor/core/theme/text_styles.dart';

import 'package:multi_vendor/core/widgets/buttons/app_back_button.dart';

class BaseAppBar extends AppBar {
  BaseAppBar({
    super.key,
    Widget? leading,
    Object? title,
    bool showLeading = true,
    super.actions,
  }) : assert(
  title == null || title is String || title is Widget,
  'title must be a String or Widget',
  ),
        super(
        title: title == null
            ? null
            : Padding(
          padding: EdgeInsets.only(top: 6.h),
          child: title is String
              ? Text(title,textAlign: TextAlign.center ,style: TextStyles.bodyMedium)  // ✅ String زي الأول
              : title as Widget,                            // ✅ Widget للحالات الخاصة
        ),
        leading: showLeading ? leading ?? _buildLeading() : const SizedBox(),
        leadingWidth: 60.sp,
        toolbarHeight: 60.sp,
        actionsPadding: EdgeInsetsDirectional.only(top: 12.h, end: 16.w),
        scrolledUnderElevation: 0,
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(8.h),
          child: const SizedBox.shrink(),
        ),
      );

  static Widget _buildLeading() {
    return const AppBackButton();
  }
}
class BaseSliverAppBar extends SliverAppBar {
  BaseSliverAppBar({
    Widget? leading,
    Color? iconColor,
    Color? iconBackgroundColor,
    super.key,
    super.expandedHeight,
    super.pinned = true,
    super.stretch = true,
    super.title,
    super.elevation,
    super.backgroundColor,
    super.flexibleSpace,
    super.actions,
  }) : super(
         toolbarHeight: 60.sp,
         bottom: PreferredSize(
           preferredSize: Size.fromHeight(24.h),
           child: const SizedBox.shrink(),
         ),
         leadingWidth: 60.sp,
         centerTitle: true,
         leading:
             leading ??
             AppBackButton(
               iconColor: iconColor,
               backgroundColor: iconBackgroundColor,
             ),
         actionsPadding: EdgeInsetsDirectional.only(top: 12.h, end: 16.w),
       );
}

