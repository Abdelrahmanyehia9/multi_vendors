import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:multi_vendor/core/extensions/context.dart';
import 'package:multi_vendor/core/extensions/date_time.dart';
import 'package:multi_vendor/core/extensions/widget.dart';
import 'package:multi_vendor/core/theme/text_styles.dart';
import 'package:multi_vendor/core/widgets/buttons/share_button.dart';
import 'package:multi_vendor/core/widgets/scaffold/base_scaffold.dart';
import 'package:multi_vendor/shared/view/mixin/scroll_visibility.dart';
import 'package:multi_vendor/core/widgets/scaffold/base_appbar.dart';
import 'package:multi_vendor/shared/data/models/news_model.dart';
import 'package:multi_vendor/shared/view/widgets/app_slider.dart';

class NewsItemDetails extends StatefulWidget {
  final NewsModel news;
  const NewsItemDetails({super.key, required this.news});

  @override
  State<NewsItemDetails> createState() => _NewsItemDetailsState();
}

class _NewsItemDetailsState extends State<NewsItemDetails>
    with ScrollTitleVisibilityMixin {
  @override
  Widget build(BuildContext context) {
    return BaseScaffold(
      appBar: BaseAppBar(
        title: title(widget.news.title),
        actions: const [
          AppShareButton(),
        ],
      ),
      body: SingleChildScrollView(
        controller: scrollController,
        child: Column(
          spacing: 16.sp,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSlider(context),
            Text(widget.news.title ?? "", style: TextStyles.labelLarge),
            Text(
              widget.news.description,
              style: TextStyles.bodyMedium.copyWith(color: context.colors.surfaceContainer),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSlider(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.end,
    spacing: 4.h,
    children: [
      AppSlider(
        images: widget.news.images,
        placeHolder: widget.news.thumbnail,
        height: 180,
      ),
      if (widget.news.createdAt != null)
        Text(
          widget.news.createdAt!.timeAgo,
          style: TextStyles.captionSmall.copyWith(
            color: context.colors.surfaceContainer,
          ),
        ).appPaddingHr,
    ],
  );

  @override
  double get titleThreshold => 230.h;
}