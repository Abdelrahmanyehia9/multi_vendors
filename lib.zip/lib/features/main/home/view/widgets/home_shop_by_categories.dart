import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:multi_vendor/core/cubit/base_bloc_consumer.dart';
import 'package:multi_vendor/core/extensions/navigation.dart';
import 'package:multi_vendor/core/widgets/app_click.dart';
import 'package:multi_vendor/features/shop/product/data/model/products_filters_model.dart';
import 'package:multi_vendor/features/shop/product/view/all_products_screen.dart';
import 'package:multi_vendor/core/routes/routes.dart';
import 'package:multi_vendor/core/widgets/app_states.dart';
import 'package:multi_vendor/core/widgets/gap.dart';
import 'package:multi_vendor/shared/data/models/category_model.dart';
import 'package:multi_vendor/shared/data/models/product_model.dart';
import 'package:multi_vendor/shared/logic/sub_categories_cubit.dart';
import 'package:multi_vendor/shared/view/widgets/app_chip.dart';
import 'package:multi_vendor/shared/view/widgets/cards/product_card.dart';
import 'package:multi_vendor/shared/view/widgets/section_header.dart';
import 'package:multi_vendor/features/main/home/logic/home_product_by_sub_category_cubit.dart';

class HomeShopByCategories extends StatefulWidget {
  const HomeShopByCategories({super.key});

  @override
  State<HomeShopByCategories> createState() => _HomeShopByCategoriesState();
}

class _HomeShopByCategoriesState extends State<HomeShopByCategories> {
  final ValueNotifier<int> _selectedItem = ValueNotifier<int>(-1);


  void _onCategoriesGetSuccess(List<CategoryModel>? i){
    if(i == null) return;
    _selectedItem.value = 0;
    context.read<HomeProductBySubCategoryCubit>().getProductByCategory(
      i[_selectedItem.value].id!,
    );
    _selectedItem.addListener(() {
      context.read<HomeProductBySubCategoryCubit>().getProductByCategory(
        i[_selectedItem.value].id!,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        BaseBlocConsumer<SubCategoriesCubit, List<CategoryModel>>(
          onSuccess: _onCategoriesGetSuccess,
          successBuilder: (categories) => _Categories(selectedItem: _selectedItem, categories: categories),
          loadingBuilder: () => _Categories(
            selectedItem: ValueNotifier(-1),
            categories: List.generate(10, (_) => CategoryModel.fake()),
          ),
        ),
        Gap.medium(),
        BaseBlocConsumer<HomeProductBySubCategoryCubit, List<ProductModel>>(
          successBuilder: (p) => ProductGrid(shrinkWrap: true, products: p),
          loadingBuilder: () => ProductGrid(
            shrinkWrap: true,
            products: List.generate(
              4,
              (_) => const ProductModel(name: '', price: null),
            ),
          ),
          emptyBuilder: AppStates.empty,
          failureBuilder: AppStates.error,
        ),
      ],
    );
  }

  @override
  void dispose() {
    _selectedItem.dispose();
    super.dispose();
  }
}

class _Categories extends StatelessWidget {
  final ValueNotifier<int> selectedItem;
  final List<CategoryModel> categories;

  const _Categories({required this.selectedItem, required this.categories});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SectionHeader(
          title: "Categories",
          hasAction: true,
          onActionTap: () => context.pushNamed(
            Routes.products,
            arguments:   ProductsScreenArgs(
              initialFilters: ProductsFiltersModel(
                categories: [categories[selectedItem.value]],
              ),
            )
          ),
        ),
        ValueListenableBuilder(
          valueListenable: selectedItem,
          builder: (context, value, child) {
            return SizedBox(
              height: 30.h,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                padding: EdgeInsets.zero,
                clipBehavior: Clip.none,
                itemBuilder: (_, i) => AppClick(
                  onTap: () {
                    selectedItem.value = i;
                  },
                  child: AppChip(
                    text: categories[i].name,
                    selected: value == i,
                  ),
                ),
                separatorBuilder: (_, _) => SizedBox(width: 12.w),
                itemCount: categories.length,
              ),
            );
          },
        ),
      ],
    );
  }
}
