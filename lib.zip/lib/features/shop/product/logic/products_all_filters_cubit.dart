import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:multi_vendor/core/cubit/base_state.dart';
import 'package:multi_vendor/core/extensions/safe_emit.dart';
import 'package:flutter/material.dart';
import 'package:multi_vendor/shared/data/models/extension/products_filters.dart';
import 'package:multi_vendor/features/shop/product/data/model/products_filters_model.dart';
import 'package:multi_vendor/features/shop/product/data/repository/product_repository.dart';

enum ProductsFilters{
  price,
  rating,
  vendor,
  stock,
  tags,
  categories,
  variants
}


class ProductsAllFiltersCubit extends Cubit<BaseState<ProductsFiltersModel>> {
  final ProductRepository _productRepository;
  ProductsAllFiltersCubit(this._productRepository) : super(const BaseState.initial());
  ProductsFiltersModel? _selectedFilters ;
  ValueNotifier<int?> totalProducts = ValueNotifier<int?>(null);
  Future<void> init([ProductsFiltersModel? filters]) async {
    safeEmit(const BaseState.loading());
    final result = await _productRepository.getProductFilters(selectedFilters: filters);
    result.fold(
      (l) => safeEmit(BaseState.failure(l)),
      (r) {
        _selectedFilters = filters;
        totalProducts.value = r.totalProducts;
        safeEmit(BaseState.success(r));
      },
    );
  }
  Future<void> getCountByFilters([ProductsFiltersModel? filters])async{
    final result = await _productRepository.getProductFilters(
      selectedFilters: filters,
    );
    result.fold(
      (_) {},
      (r) {
        totalProducts.value = r.totalProducts;
      }
    );
  }
  void setFilters(ProductsFiltersModel? filters) {
    _selectedFilters = filters;
    safeEmit(state.copyWith(
      version: DateTime.now().microsecondsSinceEpoch
    ));
  }
  void clearFilters() {
    _selectedFilters = _selectedFilters?.withoutEXCLUDES(excludes) ;
    safeEmit(state.copyWith(
      version: DateTime.now().microsecondsSinceEpoch,
    ));
  }
  ProductsFiltersModel? get selectedFilters => _selectedFilters;
  List<ProductsFilters> _excludeFilters = [];
  void exclude(List<ProductsFilters>? excludes)=>_excludeFilters = excludes??_excludeFilters;
  List<ProductsFilters> get excludes => _excludeFilters;
}
