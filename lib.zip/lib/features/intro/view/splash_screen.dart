import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:multi_vendor/core/utils/app_assets.dart';
import 'package:multi_vendor/core/widgets/scaffold/base_scaffold.dart';

import 'package:multi_vendor/features/intro/logic/splash_logic.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    SplashLogic.init(context);

  }
  @override
  Widget build(BuildContext context) {
    return  BaseScaffold(
      body: Center(
        child: SvgPicture.asset(
          AppAssets.appLogo,
        width: 80.w,
        height: 60.h,
        ),
      ),
    );
  }
}
